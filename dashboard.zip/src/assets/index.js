const ARROW = require('./img/arrows.png')
const RISE =require('./img/rise.png')
const FACE1 = require('./img/face1.png')
const FACE2 = require('./img/face2.png')
const FACE3 = require('./img/face3.png')
const FACE4 = require('./img/face4.png')


export default{
    ARROW,
    RISE,
    FACE1,
    FACE2,
    FACE3,
    FACE4
}